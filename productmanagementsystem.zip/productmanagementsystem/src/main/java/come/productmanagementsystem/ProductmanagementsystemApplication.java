package come.productmanagementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductmanagementsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductmanagementsystemApplication.class, args);
	}

}

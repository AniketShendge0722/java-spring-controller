package come.productmanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductmanagementsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.product.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.product.dto.ResponseStructure;
import com.product.entity.Product;
import com.product.service.productService;

@RestController
@RequestMapping("api/product")
public class productController {

	@Autowired
	productService productservice;
	
	@PostMapping("/create")
	public ResponseEntity<ResponseStructure<Product>>  saveAll( @RequestBody Product product)
	{
		Product Saveproduct=productservice.saveAll(product);
		ResponseStructure<Product> response=new ResponseStructure<>();
		response.setData(Saveproduct);
		response.setMessage("product save successfully");
		response.setStatusCode(HttpStatus.CREATED.value());
		return new ResponseEntity<>(response,HttpStatus.CREATED);
	}
	
	@GetMapping("findall")
	public ResponseEntity<ResponseStructure<List<Product>>>  FindAll()
	{ 
	   List<Product> findAllProduct =productservice.FindAll();
	   ResponseStructure<List<Product>> response=new ResponseStructure<>();
	   response.setData(findAllProduct);
	   response.setMessage(findAllProduct.isEmpty()?"not product found":"all product find successfully");
	   response.setStatusCode(HttpStatus.OK.value());
		return new ResponseEntity<>(response,HttpStatus.OK);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<ResponseStructure<Product>> getProductById(@PathVariable Long id) {
		
	    Optional<Product> productOptional = productservice.findById(id);
	    
	    ResponseStructure<Product> response=new ResponseStructure<Product>();
	    if (productOptional.isPresent()) {
	    	response.setData(productOptional.get());
	    	response.setMessage("product retrived successfully");
	        return new ResponseEntity<>(response,HttpStatus.OK); 
	    } else {
	           response.setData(null); // Or use an empty Product object
	           response.setMessage("Product not found with ID: " + id);
	           response.setStatusCode(HttpStatus.NOT_FOUND.value());
	           return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
	       }

	}
	
	
	@GetMapping("/findbyname")
	public ResponseEntity<ResponseStructure<Product>> findByName( @RequestParam String name)
	{
		Optional<Product> findProduct=productservice.findByName(name);
		
		ResponseStructure<Product> response=new ResponseStructure<Product>();
		if(findProduct.isPresent())
		{
			response.setData(findProduct.get());
			response.setMessage("product find successfully");
			response.setStatusCode(HttpStatus.CREATED.value());
			return new ResponseEntity<>(response,HttpStatus.OK);
		}
		else {
			response.setData(null);
			response.setMessage("product not found " +name);
			response.setStatusCode(HttpStatus.NOT_FOUND.value());
			return new ResponseEntity<>(response,HttpStatus.NOT_FOUND);
		}
	}
	
	
	@PutMapping("update/{id}")
	public ResponseEntity<Product> updateProduct(@PathVariable Long id,@RequestBody Product product)
	{
		Optional <Product> updateProduct=productservice.updateProduct(id,product);
		
		if(updateProduct.isPresent())
		{
            return ResponseEntity.ok(updateProduct.get());
		}
		else {
			
            return ResponseEntity.notFound().build();
        }
	}
	
	
	
	@DeleteMapping("/{id}")
	public ResponseEntity<ResponseStructure<String>> deleteProduct(@PathVariable Long id) {
	    
	    // Call the service layer method
	    boolean isDeleted = productservice.deleteProduct(id); 
	    
	    ResponseStructure<String> response = new ResponseStructure<>();
	    
	    if (isDeleted) {
	        // ERROR FIX 1: The ResponseStructure<String> expects a String in setData(). 
	        // We set a descriptive string instead of the Long ID.
	        response.setData("Product with ID " + id + " deleted successfully.");
	        response.setMessage("Deletion successful.");
	        response.setStatusCode(HttpStatus.OK.value());
	        
	        // Return a 200 OK response
	        return new ResponseEntity<>(response, HttpStatus.OK);
	        
	    } else {
	        // The rest of your logic for NOT_FOUND is correct
	        response.setData(null);
	        response.setMessage("Product not found with ID: " + id + ". Deletion failed.");
	        response.setStatusCode(HttpStatus.NOT_FOUND.value());
	        
	        // Return a 404 NOT FOUND response
	        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
	    }
	}

	
}

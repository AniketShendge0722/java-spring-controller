package com.product.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.entity.Product;
import com.product.repository.productRepository;

@Service
public class productService {
    
	@Autowired
    productRepository productrepository;
	
	public Product saveAll(Product p) {
		return productrepository.save(p);
	}
	
	public Optional<Product> findById(Long id)
	{
		return productrepository.findById(id);
	}
	
	public Optional<Product> updateProduct(Long id,Product product)
	{
		return productrepository.findById(id)
				.map(existingProduct->{
					existingProduct.setName(product.getName());
					existingProduct.setPrice(product.getPrice());
					return productrepository.save(existingProduct);
				});
	}
	
	public List<Product>FindAll()
	{
		return productrepository.findAll();
	}
	
	
	public Optional<Product> findByName(String name)
	{
		return productrepository.findByName(name);
	}
	
	public boolean deleteProduct(Long id)
	{
		if(productrepository.existsById(id))
		{
			productrepository.deleteById(id);
			return true;
		}
		else return false;
	}
}
  
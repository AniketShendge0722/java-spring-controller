package com.demospringbootproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemospringbootprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}

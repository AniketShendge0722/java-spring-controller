package com.demospringbootproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemospringbootprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemospringbootprojectApplication.class, args);
	}

}

package com.employeemanagementwo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeemanagementwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeemanagementwoApplication.class, args);
	}

}

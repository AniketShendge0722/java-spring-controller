package com.String;

public class ConvertLowerCaseWIthoutUsingBuiltInMethod {
	public static void main(String[] args) {
	
	String s= "ANIKET";
	for(int i=0;i<s.length();i++) {
		int res= s.charAt(i)+32;
		System.out.print( (char)res);
	}
	System.out.println();
	}
	

}

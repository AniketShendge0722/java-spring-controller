package com.String;
public class ReverseWords {
	public static void main(String[] args) {
		String s= "Atharva Gotkhindikar";
		String[] s1=s.split(" ");
		String s2= " ";
		for(int i =0 ; i<s1.length;i++) {	
		s2=s1[i];
		StringBuilder s3=new StringBuilder(s2);
		System.out.println(s3.reverse()+ " ");
		}
	}

}

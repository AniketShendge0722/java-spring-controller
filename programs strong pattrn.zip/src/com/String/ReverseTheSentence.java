package com.String;

public class ReverseTheSentence {
public static void main(String[] args) {
	String s ="E sal cup namde";
	String [] arr=s.split(" ");
	
	for(int i=arr.length-1;i>=0;i--) {
		System.out.print(arr[i]+" ");
	}
	}
}

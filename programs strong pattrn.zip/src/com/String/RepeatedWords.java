package com.String;

public class RepeatedWords {
	
	public static void main(String[] args) {

			String s="abc is a abc";

			String[] str=s.split(" ");

			for(int i=0;i<str.length-1;i++) {

				int count=0;

				for(int j=i+1;j<str.length;j++) {

					if(str[i].equalsIgnoreCase(str[j])) {

						count++;

						str[j]=" ";

					}

				}

				if(count>0) {

					System.out.println(str[i]);

				}

			}

		}

	}




package com.String;
public class CountSpace {
	public static void main(String[] args) {
		String s= " Java is Programming Language ";
		int space = 0;
		for(int i =0; i<s.length();i++) {
			if(s.charAt(i)==' ') {
				space++;	
			}		
	}
		System.out.println("Number of Space is : " +space);
	}
}

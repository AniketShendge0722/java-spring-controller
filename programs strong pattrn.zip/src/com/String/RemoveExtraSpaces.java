package com.String;

public class RemoveExtraSpaces {

	public static void main(String[] args) {
		String sc= "Aniket Shebdge  The    king of million hearts";
		sc=sc.trim();
		String s1="";
		for(int i=0;i<sc.length();i++) {
			if(sc.charAt(i)==' '&& sc.charAt(i+1)==' ') {
			}
			else {
				s1=s1+sc.charAt(i);
			}
			
		
			}
		System.out.println(s1);
			
		}
		
	}

package com.String;

public class PrintTheLargestStringAndSmallestWord {
    public static void main(String[] args) {
        String s1 = "Java is a Programming Language";
        String[] s2 = s1.split(" ");

        int max = Integer.MIN_VALUE;
        int min = Integer.MAX_VALUE; 
        int k = 0; // Index for smallest word
        int l = 0; // Index for largest word

        for (int i = 0; i < s2.length; i++) {  
            if (min > s2[i].length()) {
                min = s2[i].length();
                k = i;
            }
            if (max < s2[i].length()) {
                max = s2[i].length();
                l = i;
            }
        }

        System.out.println("Smallest Word: " + s2[k]);
        System.out.println("Largest Word: " + s2[l]);
    }
}

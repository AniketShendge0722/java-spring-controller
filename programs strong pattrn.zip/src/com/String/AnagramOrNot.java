package com.String;
import java.util.*;
public class AnagramOrNot {
	public static void main(String[] args) {
		String s = "Care";
		String s1 = "Race";
		int count = 0;
		
		s =s.toLowerCase();
		s1 =s1.toLowerCase();
		if(s.length()==s1.length()) {
//			for(int i=0; i<s.length();i++) {
//				for(int j=0; j<s1.length();j++) {
//					if(s.charAt(i)==s1.charAt(j)) {
//						count++;
//						break;
//						}}}
			
			
			char[] ch1=s.toCharArray();
			Arrays.sort(ch1);
			char[] ch2= s1.toCharArray();
			Arrays.sort(ch2);
			int j =0;
			int i =0;
			while (i<ch1.length) {
				if(ch1[i]==ch2[j]) {
				count++;}
				else
					break;
				i++;
				j++;
				
			}
			if(count==s.length()) {
				System.out.println(s+ " ==> The Given String is Anagram : " );
			 } 
			else {
				System.out.println( s1+ " ==>  The Given  String Is Not Anagram " );
			}
		}
			else {
				System.out.println(" not anagram ");
			}
	}
		
	}  
	



package com.String;

public class PalindromOrNot {
public static void main(String[] args) {
	String s1="Madam";
	String s2 = "";
	for(int i = s1.length()-1;i>=0;i--) {
		s2=s2+s1.charAt(i);
		
	}
	System.out.println(s1);
	System.out.println(s2);
	
	if(s1.equalsIgnoreCase(s2)) {
		System.out.println(" The Given String is palindrome");
	}
	else {
		System.out.println(" The Given String is Not Palindrome ");
	}
}
}

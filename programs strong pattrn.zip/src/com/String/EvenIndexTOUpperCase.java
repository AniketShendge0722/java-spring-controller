package com.String;
public class EvenIndexTOUpperCase {
public static void main(String[] args) {
	String s= "Volley Ball";
	for(int i=0;i<s.length();i++) {
		char ch =s.charAt(i);	
		if(i%2==0 && ch >= 'a' && ch<='z') {
			System.out.print((char) (ch-32));
		}
		else {
			System.out.print(ch);
			}}
}
}

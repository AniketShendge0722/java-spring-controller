package com.String;

public class RemoveDublicatesFromSecoundString {
	public static void main(String[] args) {
		String s1= "aaabbbccc";
		String s2 = "abcdddaaabbcc";
		StringBuilder str1=new StringBuilder(s1.toLowerCase());
		StringBuilder str2=new StringBuilder(s2.toLowerCase());
		
		for(int  i=0;i<str1.length();i++) {
			for(int j=0; j<str2.length();j++) {
			if(str1.charAt(i)==str2.charAt(j)) {
				str2.setCharAt(j,' ');
			}
			}
		}
		System.out.println(str2);
		
	}

}

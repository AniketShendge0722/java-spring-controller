package com.String;

public class ConvertUpperCaseWIthoutUsingBuiltI {
	public static void main(String[] args){
		String s= "program";
		for(int i= 0; i<s.length();i++) {
			int res = s.charAt(i)-32;
			System.out.print((char)res);
		
		}
		System.out.println();
		}
}

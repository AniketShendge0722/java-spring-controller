package com.String;
public class PanaGramOrNot {
	public static void main(String[] args) {
		String s1 = "The quick brown fox jumps over a lazy dog";
		s1 =s1.toLowerCase();
		char []ch =s1.toCharArray();
		int count =0;
		for(int i =0; i<s1.length();i++) {
			for(int j= i+1; j<ch.length;j++) {
				
				if(ch[i]==ch[j]) {
					ch[j]=' ';	
				}
			}
		}
	
		for (int i =0; i<ch.length;i++) {
			if(ch[i]>='a'&& ch[i]<='z'&& ch[i]!=' ') {
				count++;
				
			}
			
		}
		if(count ==26) {
			System.out.println(" Panagram ");
		}
		else {
			System.out.println("Not Panagram");
		}
		
	}
}

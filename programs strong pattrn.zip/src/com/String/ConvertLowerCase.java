package com.String;

public class ConvertLowerCase {
	public static void main(String[] args) {
		String s= "JAVA";
				System.out.println(s.toLowerCase());
	}

}

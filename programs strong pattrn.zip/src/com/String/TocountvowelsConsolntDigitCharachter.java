package com.String;
public class TocountvowelsConsolntDigitCharachter{
    public static void main(String[] args) {
        String s = "sds234$%^aei";
        int vowels = 0;
        int consonants = 0;
        int specialChars = 0;
        int digits = 0;
        
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (Character.isDigit(ch)) { //isDigit(ch) method ahe 
                digits++;
            } else if (Character.isLetter(ch)) {
                if (ch == 'A' || ch == 'a' || ch == 'E' || ch == 'e' || ch == 'I' || ch == 'i' ||
                    ch == 'O' || ch == 'o' || ch == 'U' || ch == 'u') {
                    vowels++;
                } else {
                    consonants++;
                }
            } else {
                specialChars++;
            }
        }
        
        System.out.println("Number of vowels: " + vowels);
        System.out.println("Number of consonants: " + consonants);
        System.out.println("Number of digits: " + digits);
        System.out.println("Number of special characters: " + specialChars);
    }
}

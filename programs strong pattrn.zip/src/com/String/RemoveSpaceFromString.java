package com.String;

public class RemoveSpaceFromString 
{
	public static void main(String[] args) 
	{
		String  s = " java is Programing language ";
		for(int i=0; i<s.length();i++) 
		{
			if(s.charAt(i)!=' ') 
			{
				System.out.print(s.charAt(i));
				}
			}
		}
	}

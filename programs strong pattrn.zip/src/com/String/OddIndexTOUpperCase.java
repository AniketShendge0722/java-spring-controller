package com.String;
public class OddIndexTOUpperCase {
	public static void main(String[] args) {
		String s= "volley ball";
		for(int i=0;i<s.length();i++) {
			char ch =s.charAt(i);	
			if(i%2==1 && ch >= 'a' && ch<='z') {
				System.out.print((char) (ch-32));
			}
			else {
				System.out.print(ch);
				}}
	}
	}


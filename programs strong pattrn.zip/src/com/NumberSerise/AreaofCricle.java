package com.NumberSerise;
import java.util.Scanner;


public class AreaofCricle {
	
		public static void main(String[] args) {
			try (Scanner s = new Scanner(System.in)) {
				System.out.println("enter the radius");
				double radius=s.nextInt();

				reactangle(radius);
			}
			
			}
			
			
			public static void reactangle(double radius) {
				double area=(22/7)*radius*radius ;    //area=3.14*radius*radius;
				System.out.println(area);
				
			}
	}



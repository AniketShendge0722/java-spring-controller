package com.NumberSerise;
//import java.util.Scanner;

public class NumberSerise {
	public static void main(String[] args) {
		
//		System.out.println("Enter the Numbers below");
//		Scanner s = new Scanner(System.in);
//		 int num  = s.nextInt();
		
		int num = 1234;
		int result= num%10;
		System.out.println( " Extract number  is " + result );

		
	} 

}

package com.NumberSerise;
import java.util.Scanner;

public class Simpleintrest2 {
	public static void main(String[] args) {
		System.out.println("Enter the Amount ");
		try (Scanner s = new Scanner(System.in)) {
			double p = s.nextDouble();
			System.out.println("Enter rate of intrest :  ");
			double r = s.nextDouble();
			System.out.println("Enyter the time of period");
			double t = s.nextDouble();
			
			double intrest =calculateInterest(p,r,t);
			System.out.println("simple intrest : " + intrest );
		}
		
	}
		public static double calculateInterest(double p,double r , double t ) {
			return (p*r*t)/100;
		}
}

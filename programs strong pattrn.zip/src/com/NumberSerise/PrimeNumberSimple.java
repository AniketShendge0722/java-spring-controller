package com.NumberSerise;
import java.util.Scanner;
public class PrimeNumberSimple {
	public static void main(String[] args) {
		
		        try (Scanner s = new Scanner(System.in)) {
		        	System.out.print("Enter the  Number :");
					int num=s.nextInt();
					boolean isPrime=true;
					if(num<=1 || num>0){
					    System.out.println(num+" Is not prime");
					}
					else{
      
					for(int i=1;i<=num/2;i++){
					    if(num%i==0){
					 isPrime=false;
					    }
					}
					if(isPrime){
					    System.out.println(num+" is Prime number");
					}
					else{
					    System.out.println(num+" not Prime number");
					}
                 }
	           }        
		   }
		}
	
	


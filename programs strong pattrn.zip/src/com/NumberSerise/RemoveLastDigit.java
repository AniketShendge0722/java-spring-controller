package com.NumberSerise;

public class RemoveLastDigit {

	public static void main(String[] args) {
		int num =12345;
		int result=num/10;
		System.out.println("The Result is :- " + result);
	}
}

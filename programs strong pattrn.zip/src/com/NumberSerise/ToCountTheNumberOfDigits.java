package com.NumberSerise;
import java.util.Scanner;
public class ToCountTheNumberOfDigits {
	public static void main(String[] args) {
		System.out.println("Enter the numbers ");
		try (Scanner s = new Scanner(System.in)) {
			int num = s.nextInt();
			int  count =0;
			while(num !=0) {	
				count ++;
				num = num/10;	
			}
			System.out.println(" The Total Number Entere is " + count);
		}	
		
	}

}

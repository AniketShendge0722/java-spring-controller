package com.NumberSerise;
import java.util.Scanner;

public class SumOfFactors {
public static void main(String[] args) {
	System.out.println("");
	 try (Scanner s = new Scanner(System.in)) {
		System.out.print("Enter a number: ");
		 int num = s.nextInt();
		 int sum = 0;
		 
		 for(int i =1; i<=num; i++) {
			 if (num%i ==0) {
				 sum+=i;
			 }
			 }
		 System.out.println("Sum Of Factor of " + num + " is : "+ sum );
	}
}
	 
	
	
	
	
	
}



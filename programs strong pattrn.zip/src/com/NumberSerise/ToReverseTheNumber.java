package com.NumberSerise;
import java.util.Scanner;

public class ToReverseTheNumber {
	public static void main(String[] args) {
		System.out.println("*** Reverse Number Program ***");
		try (Scanner s = new Scanner(System.in)) {
			// Ask the user for a number
			System.out.print("Enter a number: ");
			
			int num = s.nextInt();

			int reversed = 0;
			
			// Reverse the number
			while (num != 0) {
			    int digit = num % 10;  // Extract the last digit
			    reversed = reversed * 10 + digit;  // Add it to the reversed number
			    num = num / 10;  // Remove the last digit from the number
			}

			// Display the reversed number
			System.out.println("Reversed number: " + reversed);
		}
		
	}

}


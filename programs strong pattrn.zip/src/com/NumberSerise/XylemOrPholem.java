package com.NumberSerise;
import java.util.Scanner;


public class XylemOrPholem {
	public static void main(String[] args)
	{
		
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter a Number");
			int  num=sc.nextInt();
			int ld=num%10;
			num=num/10;
			
			int is=0;//inner sum
			while(num>9)//This is the logic for first digit 
			{
				is=is+num%10;
				num=num/10;	
			}
			int os=ld+num;//os is outer sum 
			if(os==is) {
				System.out.println("The given number is xylem");
			}
			else
			{
				System.out.println("The given number is phloem");
			}
		}
		
	}


}

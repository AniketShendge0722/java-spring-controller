package com.NumberSerise;
import java.util.Scanner;

public class SimpleIntrestProg {
  // Method to calculate simple interest
	    public static double calculateInterest(double principal, double rate, double time) {
	        return (principal * rate * time) / 100; // Formula: (P × R × T) / 100
	    }

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        // Taking input from the user
	        System.out.print("Enter Principal amount: ");
	        double principal = scanner.nextDouble();

	        System.out.print("Enter Rate of Interest (in % per year): ");
	        double rate = scanner.nextDouble();

	        System.out.print("Enter Time period (in years): ");
	        double time = scanner.nextDouble();

	        // Calculating and displaying Simple Interest
	        double interest = calculateInterest(principal, rate, time);
	        System.out.println("Simple Interest: " + interest);

	        scanner.close(); // Closing the scanner
	    }
	}




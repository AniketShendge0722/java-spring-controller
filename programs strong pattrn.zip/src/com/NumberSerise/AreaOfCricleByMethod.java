package com.NumberSerise;
import java.util.Scanner;

public class AreaOfCricleByMethod {
	
	    // Method to calculate the area of a circle
	    public static double getArea(double radius) {
	        return Math.PI * radius * radius; // Formula: πr²
	    }

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        // Taking input from the user
	        System.out.print("Enter the radius of the circle: ");
	        double radius = scanner.nextDouble();

	        // Calculating and displaying the area
	        double area = getArea(radius);
	        System.out.println("Area of the circle: " + area);

	        scanner.close(); // Closing the scanner
	    }
	}




package com.NumberSerise;

public class GivenNumberSunnyOrNot {
	public static void main(String[] args) 
	{
		int num=9;
		int num1=num+1;
		int a=0;
		for(int i=1;i<=num/2;i++)
		  {
			  
			if(num1==i*i)
			{  
				a=i*i; 
				break;
			}
		
		  }
		if(num1==a)
		{
			System.out.println(num+""+"is a sunny number");
		}
		else {
			System.out.println(num+""+"is not Sunny number");
		}
		
	}


}

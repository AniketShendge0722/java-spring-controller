package com.NumberSerise;
import java.util.Scanner;
public class TheAvgOfTheDigit {
	public static void main(String[] args) {
		System.out.println("Eneter the number ");
		try (Scanner s = new Scanner(System.in)) {
			int num = s.nextInt();
			int sum=0;
			int count =0;
			while(num!=0) {
				sum= sum +num%10;
				count++;
				num=num/10;
			}
			System.out.println("The result is : " + sum/count );
		}
	}

}

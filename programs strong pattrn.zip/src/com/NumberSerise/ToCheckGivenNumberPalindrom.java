package com.NumberSerise;
import java.util.Scanner;

public class ToCheckGivenNumberPalindrom {
	public static void main(String[] args) {
		try (Scanner s = new Scanner(System.in)) {
			System.out.println("Enter a Number ");
			int num =s.nextInt();
			int originalNum= num;
			int reversed =0;
			
			while(num !=0) {
				reversed = reversed*10 ;
				num = num /10;
}
			if( originalNum==reversed) {
				System.out.println( originalNum +" is a Palindrom number ");
			}
			else {
				System.out.println( originalNum + " is  not a  Palindrom number");

}
		}
	}
}




       
      


   

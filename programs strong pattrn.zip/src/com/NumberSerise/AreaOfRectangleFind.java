package com.NumberSerise; // Fixed package name typo
import java.util.Scanner;

public class AreaOfRectangleFind { // Fixed class name format

    // Method to calculate the area of a rectangle
    public static int getArea(int length, int width) {
        return length * width;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Corrected Scanner declaration

        // Taking input from the user
        System.out.print("Enter the length of the rectangle: ");
        int length = scanner.nextInt();

        System.out.print("Enter the width of the rectangle: ");
        int width = scanner.nextInt();

        // Calculating and displaying the area
        int area = getArea(length, width);
        System.out.println("Area of the rectangle: " + area);

        scanner.close(); // Closing the scanner to avoid resource leaks
    }
}

package com.NumberSerise;

public class add {
public static void main(String[] args) {
	int a = 121; 
	int sum=0;
	while(a>0) {
		int tem=a%10;
		sum+=tem;
		a/=10;
		
	}
	 System.out.println(sum);
	 
}
}

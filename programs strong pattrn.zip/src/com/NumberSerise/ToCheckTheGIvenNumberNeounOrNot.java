package com.NumberSerise;

public class ToCheckTheGIvenNumberNeounOrNot {
	public static void main(String[] args)
	{
		int num=12;
		int sum=0;
		int num1=num*num;
		while(num1!=0)
		{  
			int rem=num1%10;
			sum=sum+rem;
			num1=num1/10;
				
		}
		if(sum==num)
		{
			System.out.println(num +"is neon number");
		}
		else
		{
			System.out.println(num+"is neon number");
			
		}
	}


}

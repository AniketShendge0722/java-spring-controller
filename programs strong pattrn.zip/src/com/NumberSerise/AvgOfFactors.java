package com.NumberSerise;
import java.util.Scanner;


public class AvgOfFactors {

	public static void main(String[] args) {
		try (Scanner s = new Scanner(System.in)) {
			System.out.println("Enetr a Number :  ");
			int num = s.nextInt();
			int sum = 0;
			int count = 0;
			for (int i = 1; i<= num; i++) {
			if(num %i == 0) {
			sum +=i;
			count++;
			}
}
double average = (double) sum/count;
System.out.println("Average of factors of " + num + " is: " + average);
		}
	
}
}
       
         

    
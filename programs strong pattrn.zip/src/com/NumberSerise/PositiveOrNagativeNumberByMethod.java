package com.NumberSerise;

import java.util.Scanner;

public class PositiveOrNagativeNumberByMethod {
	public static void main(String[] args) {
		System.out.println("Enter the number : ");
		try (Scanner s = new Scanner(System.in)) {
			int num  = s.nextInt();
			postiveOrNegative(num);
		}
		
		}
	public static void postiveOrNegative(int num) {
		if(num>0) {
			
			System.out.println( num + " The Enetered  Number is Postive");
	
		}
		
		else {
			System.out.println( " The Enetered Number is:   " + num + "  is nagative  ");
		}
		
	}

}

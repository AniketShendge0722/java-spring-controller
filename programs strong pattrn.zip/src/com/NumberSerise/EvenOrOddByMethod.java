package com.NumberSerise;
import java.util.Scanner;

public class EvenOrOddByMethod {
	public static void main(String[] args) {
		System.out.println("Enter the number : ");
		try (Scanner s = new Scanner(System.in)) {
			int num  = s.nextInt();
			evenOrOdd(num);
		}
		
		}
	public static void evenOrOdd(int num) {
		if(num%2==0) {
			
			System.out.println( num + " The Enetered  Number is Even");
	
		}
		else {
			System.out.println( " The Enetered Number is:   " + num + " :- and it is odd number ");
		}
		
	}
	}



package com.NumberSerise;
import java.util.Scanner;

public class PrimeNumber {

	   public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        // Taking input from the user
	        System.out.print("Enter a number: ");
	        int num = scanner.nextInt();

	        // Check if the number is prime
	        boolean isPrime = checkPrime(num);

	        // Display the result
	        if (isPrime) {
	            System.out.println(num + " is a Prime Number.");
	        } else {
	            System.out.println(num + " is NOT a Prime Number.");
	        }

	        scanner.close();
	    }

	    // Method to check if a number is prime
	    public static boolean checkPrime(int num) {
	        if (num <= 1) {
	            return false; // Numbers 0 and 1 are not prime
	        }
	        
	        // Check divisibility from 2 to sqrt(num) (Optimized)
	        for (int i = 2; i <= Math.sqrt(num); i++) {
	            if (num % i == 0) {
	                return false; // If divisible, not prime
	            }
	        }
	        
	        return true; // If no divisors found, it's prime
	    }
	}

	


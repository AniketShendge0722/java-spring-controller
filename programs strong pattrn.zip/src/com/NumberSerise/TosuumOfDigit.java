package com.NumberSerise;
import java.util.Scanner;
public class TosuumOfDigit {

	public static void main(String[] args) {
		System.out.println("Enter the numbers ");
		
		try (Scanner s = new Scanner(System.in)) {
			int num = s.nextInt();
			
			int  sum =0;
			
			while(num !=0) {
				
				sum = sum + num%10;
				num = num/10;	

			}
			System.out.println("The result is := " + sum );
		}
}
}

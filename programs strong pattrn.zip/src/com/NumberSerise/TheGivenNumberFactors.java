package com.NumberSerise;
import java.util.Scanner;
public class TheGivenNumberFactors {
	public static void main(String[] args) {
		System.out.println("Enter the Number :");
		try (Scanner s = new Scanner(System.in)) {
			int num = s.nextInt();
			 System.out.println("Factors of " + num + " are: ");
			
			 for(int i = 1; i<= num; i++) {
				 if(num%i ==0 ) {
					 System.out.println(i+"  is Factor  " );
				 }
				 else {
					 System.out.println(i+"   is   not Factor  " );
				 }
			
              }
	 	}

   }

}
       
   

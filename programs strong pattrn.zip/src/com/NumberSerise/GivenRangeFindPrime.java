package com.NumberSerise;

public class GivenRangeFindPrime {
	
	    public static void main(String[] args) {
	        System.out.println("Prime numbers between 3 and 12 are:");

	        for (int num = 3; num <= 12; num++) {
	            boolean isPrime = true; // Assume the number is prime

	            if (num <= 1) {
	                isPrime = false; // Numbers 0 and 1 are not prime
	            } else {
	                // Check divisibility from 2 to sqrt(num) (Optimized approach)
	                for (int i = 2; i * i <= num; i++) {
	                    if (num % i == 0) {
	                        isPrime = false; // If divisible, not prime
	                        break;
	                    }
	                }
	            }

	            // Print the number if it's prime
	            if (isPrime) {
	                System.out.print(num + " ");
	            }
	        }
	    }
	}



package com.NumberSerise;

import java.util.Scanner;

public class TheLargestDigitInNumber {
	public static void main(String[] args) {
		System.out.println("Enter the Number ");
		try (Scanner s = new Scanner(System.in)) {
			int num = s.nextInt();
			
			int largest = num%10;
			while(num!=0) {
				if(num%10>largest) {
					largest=num%10;
				}
				    num=num/10;
			}
				
			System.out.println("The LargestDigit : " +  largest);
		}
		
	}

}


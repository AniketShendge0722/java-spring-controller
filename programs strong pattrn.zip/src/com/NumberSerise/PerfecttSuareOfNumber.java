package com.NumberSerise;
import java.util.Scanner;
public class PerfecttSuareOfNumber {



	
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        // Taking input from the user
	        System.out.print("Enter a number: ");
	        int num = scanner.nextInt();

	        // Calculate the square root of the number
	        int sqrt = (int) Math.sqrt(num);

	        // Check if the square of sqrt equals the number
	        if (sqrt * sqrt == num) {
	            System.out.println(num + " is a Perfect Square.");
	        } else {
	            System.out.println(num + " is NOT a Perfect Square.");
	        }

	        scanner.close();
	    }
	}






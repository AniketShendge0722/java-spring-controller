package com.NumberSerise;

import java.util.Scanner;
public class StrongNumberOrWeakNumber {

	    public static void main(String[] args) {
	        try (Scanner scanner = new Scanner(System.in)) {
				System.out.print("Enter a number: ");
				int num = scanner.nextInt();
				int originalNum = num;
				int sum = 0;

				// Loop to calculate the sum of factorials of digits
				while (num > 0) {
				    int digit = num % 10; // Extract the last digit
				    sum += factorial(digit); // Add factorial of the digit to sum
				    num /= 10; // Remove the last digit
				}

				// Check if sum of factorial of digits equals the original number
				if (sum == originalNum) {
				    System.out.println(originalNum + " is a Strong Number.");
				} else {
				    System.out.println(originalNum + " is a Weak Number.");
				}
			}

	       
	    }

	    // Method to calculate factorial of a number
	    public static int factorial(int n) {
	        int fact = 1;
	        for (int i = 1; i <= n; i++) {
	            fact = fact*i;
	        }
	        return fact;
	    }
	}



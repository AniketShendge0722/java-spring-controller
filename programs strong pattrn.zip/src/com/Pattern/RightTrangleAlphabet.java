package com.Pattern;

public class RightTrangleAlphabet 
{
	public static void main(String[] args) 
	{
		int n=4;
		char ch= 'A';
		int a=2;
		for(int i =1; i<=n; i++)
		{
			for(int j =1; j<=n;j++) 
			{
				if(i+j<=n+1) 
				{
					System.out.print(ch++ + " ");
				}
					else 
					{
						System.out.println(a++ + " ");
					}
				}
			
		}
			System.out.println();			
					
				
	}

}

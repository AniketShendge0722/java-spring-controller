package com.Pattern;

public class RightTranigle {
	public static void main(String[] args) {
		
	int n =5;
	for(int i=1;i<=n*2-1; i++) 
	{
			for(int j=1; j<n+1;j++) 
		{
			 if(i>=j && i+j<=n*2)
			 {
					System.out.print("* ");
			 }	
			 else {
				 System.err.print(" ");
			 }
		}
			System.out.println();
		
		
		
	}
	

}
}
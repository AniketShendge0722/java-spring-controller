package com.Pattern;

public class AplhaNumricTrainglr {
	public static void main(String[] args) {
		int n=5;
		char ch = 'A';
		int a = 1;
		for(int i =1; i<=n; i++) {
			for(int j =1; j<=n;j++) {
				if(i<=j) {
					if(i%2==0) {
						System.out.print(a++ + " ");
						
					}
					else {
						System.out.print(ch++ + " ");
					}
					
				}
			}
			System.out.println();
		}
		
	}

}

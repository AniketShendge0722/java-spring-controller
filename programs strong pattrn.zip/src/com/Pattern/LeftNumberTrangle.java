package com.Pattern;

public class LeftNumberTrangle {
	public static void main(String[] args) {
		
	}

}

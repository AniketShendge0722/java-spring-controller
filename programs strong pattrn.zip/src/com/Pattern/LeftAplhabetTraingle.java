package com.Pattern;

public class LeftAplhabetTraingle {

  public static void main(String[] args) {
	
	  int n=  4;
		char a = 'A';
		
		for(int i=1; i<= n; i++) 
		{
			for (int j = 1; j<n+i; j++)
			
			{
				if(i+j>n) {
					System.out.print(a +" ");
					a++;
				}
				else {
					System.out.print("  ");
				}
				
			}
			System.out.println();
		}
}
}

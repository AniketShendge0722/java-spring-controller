package com.Pattern;

public class PrintOneToTenInLeftTrangle {
	public static void main(String[] args) {
		int n= 1;
		
		for(int i = 1; i<=n; i++) {
			for( int j=1; j<=n; j++) {
				if(i+j<=n+1) {
					System.out.println(n+" ");
					n++;
				
				}
				else {
					System.out.println("  ");
				
				}
				System.out.println();
				
			}
		}
		
	}

}

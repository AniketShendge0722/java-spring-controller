package com.Thinkitive;
import java.util.Scanner;

public class PrimeNumberOroddNumber {

	public static void main(String[] args) {
		int a= 7;
		if (a%2==0) {
			System.out.println(" not a even");
		}
		else {
			System.out.println("odd");
		}
 try (Scanner s = new Scanner(System.in)) {
System.out.print("Enter the  Number :");
	int num=s.nextInt();
	boolean isPrime=true;
	if(num<=1 || num>0){
	    System.out.println(num+" Is not prime");
	}
	else{
		
	for(int i=1;i<=num/2;i++){
	    if(num%i==0){
	 isPrime=false;
	    }
	}
	if(isPrime){
	    System.out.println(num+" is Prime number");
	}
	else{
	    System.out.println(num+" not Prime number");
							}
		                 }
			           }        
				   
				
			
			


	}
}

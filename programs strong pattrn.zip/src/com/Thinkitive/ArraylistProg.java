package com.Thinkitive;

import java.util.ArrayList;

public class ArraylistProg {
	public static void main(String[] args) {
		ArrayList<String> list =new ArrayList<String>();
		list.add("apple");
		list.add("banana");
		list.add("cherry");
		list.add("manuka");
		list.add("badam");
		list.add("keli");
		
		String SearchElement ="keli";
		int index=list.indexOf(SearchElement);
		if(index != -1) {
			System.out.println("elemen is "+ index);
		}
		else {
			System.out.println("not found "+ index);
		}
		
	}
	

}

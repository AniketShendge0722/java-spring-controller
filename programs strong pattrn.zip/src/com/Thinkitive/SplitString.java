package com.Thinkitive;

public class SplitString {
public static void main(String[] args) {
	String s = "Hello0";
	int mid = s.length()/2;
	
	String part1 = s.substring(0,mid);
	String part2 = s.substring(mid);
  
	
	part1 = new StringBuilder (part1).reverse().toString();
	part2 = new StringBuilder (part2).reverse().toString();
	
	System.out.println(part2 +"  "+ part1);
}
}

	

package com.Thinkitive;

public class ReverseString {

	public static void main(String[] args) {
		String s= "Hello World ";
		for(int i = s.length()-1;i>=0;i--) {
			System.out.print(s.charAt(i));
		}
		
	}
}

package com.Thinkitive;
import java.util.Arrays;
public class FourthLagestArrary {
	public static void main(String[] args) {
		int[] arr = {1,2,3,45,6,6,7,};
		if(arr.length < 4) {
			System.out.println("the size of array is greter ");
		}
		else {
			 Arrays.sort(arr); 
			System.out.println("fourth element is "+ arr[arr.length-4]);
		}
		
	}

}

package com.programing;
import java.util.Scanner;

public class UpperOrLowerOrDigitOrSpl {
	public static void main(String[] args) {
		try (Scanner s = new Scanner(System.in)) {
			System.out.println("Enter The Value in Below :-");
			char ch = s.next().charAt(0);
			if(ch<='Z' && ch>='A'|| ch>= 'a'&& ch<= 'z') {
				System.out.println(ch+ " Is Given Character is Aphabet ");
				
			}
			
			else if (ch>= '0' && ch <= '9') {
				System.out.println(ch+ " Is Character is  Digit ");
			}
			else {
				System.out.println( ch +"  Is Entered  Character is Special Character ");
			}
		}
		
	}
	

}

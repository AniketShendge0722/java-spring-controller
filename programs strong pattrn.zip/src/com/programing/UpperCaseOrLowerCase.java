package com.programing;
import java.util.Scanner;

public class UpperCaseOrLowerCase {
public static void main(String[] args) {
	try (Scanner s = new Scanner(System.in)) {
		System.out.println("Enter the Alphabet Below:-");
		char ch  = s.next().charAt(0);
		if(ch>= 'A' && ch<= 'Z'){
			System.out.println( "  The Entered the Character"  +  ch  + "  is UpperCase Alphabet ");
			
		}
		else if  ( ch >='a' && ch <= 'z'){
			System.out.println("The Entered the Character  "  + ch + "  is LowerCase Alphabet");
			
		}
 
		else {
			System.out.println(ch + "  The Entered the Character"
					+ " " + ch + "  is not Alphabet");
		}
	}
	
	
}
}

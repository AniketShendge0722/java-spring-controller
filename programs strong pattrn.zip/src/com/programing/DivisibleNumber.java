package com.programing;
import java.util.Scanner;

public class DivisibleNumber {
	public static void main(String[] args) {
		try (Scanner s = new Scanner(System.in)) {
			System.out.println("Enterd the Value in Bellow ");
			int num =s.nextInt();
			if(num%3==0 && num%5==0 ) {
				System.out.println(num + " Hi Hello ");
			}
			else if(num%3==0) {
				System.out.println(num + " Hie");
			}
			else if(num%5==0) {
				System.out.println(num + " Hello");
			}
			else {
				System.out.println( num+ " bye");
			}
		}
	}

}

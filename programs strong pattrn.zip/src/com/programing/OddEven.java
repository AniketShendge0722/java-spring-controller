package com.programing;
import java.util.Scanner;

public class OddEven {
	public static void main(String[] args) {
		try (Scanner s = new Scanner(System.in)) {
			System.out.println("Eneter The number Below:-");
			int num  = s.nextInt();
			if(num%2==0)
			{
				System.out.println( num + " The Enetered  Number is Even");

			}
			else {
				System.out.println(num+ " The Enetered Number is odd number ");
			}
		}
		
	}

}

package com.advjava;

public class ConsumerDriver {
	public static void main(String[] args) {
		Accept<Integer> obj1 = (a) -> { System.out.println(a+ 10);};
		Accept<String> obj2 = (a) -> { System.out.println(a+ "Aniket");};
		
		obj1.accept(10);
		obj2.accept("_007");
	}

}

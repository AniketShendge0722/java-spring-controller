package com.advjava;

public class demo {
    private int a;
    


    private demo(int a) {
        this.a = a;
    }

//   factory method
    static demo obj; //null
    public static demo getDemo(int a) {
    	if (obj==null) {
    		obj= new demo(a);
    		return obj;
    	}
        return obj; 
        
    }

//   
//    public void show() {
//        System.out.println("Value of a: " + a);
//    }
//
//    public static void main(String[] args) {
//        demo d = demo.getDemo();
//        d.show();
//    }
//}
}

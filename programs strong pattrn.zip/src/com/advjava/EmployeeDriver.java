package com.advjava;
import java.io.*;

public class EmployeeDriver {
    public static void main(String[] args) {
        String path = "D:\\Qspider\\Java advance\\EmployeeInfo.txt";

        try (FileOutputStream fos = new FileOutputStream(path);
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            
            
            Employee e = new Employee(1, "Aniket Shendge");


            oos.writeObject(e);
            System.out.println("Employee object has been serialized successfully!");
        
        } catch (IOException ex) {
            System.out.println("Error writing to file: " + ex.getMessage());
        }
    }
}


//
//package com.advjava;
//import java.io.*;
//public class EmployeeDriver {
//	public static void main(String[] args) throws FileNotFoundException {
//		String path = "D:\\Qspider\\Java advance\\EmployeeInfo.txt";
//		
//		FileOutputStream fos = new FileOutputStream(path);
//		ObjectOutputStream oos =new ObjectOutputStream(fos);
//		Employee e = new Employee(1,"aniket shendge ")
//		oos.writeObject(e);
//		fos.close();
//		
//	}
//
//}

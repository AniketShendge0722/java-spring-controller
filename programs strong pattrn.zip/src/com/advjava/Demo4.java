package com.advjava;

import java.util.ArrayList;

public class Demo4 {
	public static void main(String[] args) {
		ArrayList<Integer> al= new ArrayList<> ();
		ArrayList<String> al2= new ArrayList<> ();
		al.add(10);
		al.add(122);
		al.add(10);
		al.add(122);
		al.add(10);
		al.add(12);
		al.add(120);
		al2.add(132 + " anie");
		System.out.println( "Before Remove => 10 " + al);
		System.out.println(al2);
		
		al.removeIf((a)->{return a.equals(10);});
		System.out.println( "After Remove => 10 " +al);
	}

}

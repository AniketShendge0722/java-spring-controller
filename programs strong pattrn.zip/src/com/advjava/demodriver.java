package com.advjava;

public class demodriver {
	public static void main(String[] args) {
	
		demo obj1 = demo.getDemo(10);
		System.out.println(obj1);
		
		
	}

}

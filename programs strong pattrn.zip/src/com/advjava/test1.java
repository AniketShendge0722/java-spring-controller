package com.advjava;

public class test1 {
	public static void main(String[] args) {
		test obj = (int a)-> {
			a= a+10;
			System.out.println(a);};
			
		}
	}

}

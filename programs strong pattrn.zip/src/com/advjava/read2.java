package com.advjava;

import java.io.FileInputStream;
import java.io.IOException;

public class read2 {  

    public static void main(String[] args) {
        String path = "D:\\Qspider\\Java advance\\read2.txt"; 

  
        try (FileInputStream fis = new FileInputStream(path)) {
            int i = fis.read();
            while (i != -1) {
                System.out.print((char) i); 
                i = fis.read();
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}

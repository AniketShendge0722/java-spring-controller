package com.advjava;

import java.io.FileOutputStream;
import java.io.IOException;

public class secound { 

    public static void main(String[] args) {
        String path = "D:\\Qspider\\Java advance\\second.txt";
        int n = 4;

      
        try (FileOutputStream fos = new FileOutputStream(path, true)) {
            for (int i = 1; i <= 10; i++) {
                String s = n + " X " + i + " = " + (n * i) + "\n";
                fos.write(s.getBytes()); 
            }
            System.out.println("Multiplication table of " + n + " written successfully.");
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }
}

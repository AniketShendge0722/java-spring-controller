package com.advjava;

import java.util.function.Predicate;

public class Demo1 {

    public static void main(String[] args) {
        Predicate<Integer> obj = (a) -> a % 2 == 0;
        Predicate<String> obj1 = (a) -> a.length() >= 2;
        Predicate<Double> obj2 = (a) -> a / 2 <= 5;
        Predicate<String> obj3 = (a) -> a.startsWith("a");

        System.out.println(obj.test(10));        // true
        System.out.println(obj1.test("world"));  // true
        System.out.println(obj2.test(10.5));     // false
        System.out.println(obj3.test("apple"));  // true
    }
}

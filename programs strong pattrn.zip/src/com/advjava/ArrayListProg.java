package com.advjava;

import java.io.IOException;
import java.util.ArrayList;

public class ArrayListProg {
	public static void main(String[] args) throws IOException {
		ArrayList<Integer> al= new ArrayList<> ();
		ArrayList<String> al2= new ArrayList<> ();
		al.add(10);
		al.add(122);
		al.add(10);
		al.add(122);
		al.add(10);
		al.add(12);
		al.add(120);
		al2.add(132 + " anie");

		System.out.println(al2);
		for(Integer i:al) {
			System.out.println(i);
			al.forEach((a)-> {System.out.println(a);});
			Runtime runtime =Runtime.getRuntime();
			Process exec = runtime.exec("mspaint");
			
		}
	}

}



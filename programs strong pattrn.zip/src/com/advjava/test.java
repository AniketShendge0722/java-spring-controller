package com.advjava;

public class test {
	public void print (int a)
}

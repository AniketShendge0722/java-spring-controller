package com.advjava;

import java.io.FileOutputStream;
import java.io.IOException;

public class read { 

    public static void main(String[] args) {
        String path = "D:\\Qspider\\Java advance\\read.txt";
        
        
        try (FileOutputStream fos = new FileOutputStream(path, true)) {
            String s = "hello";
            byte[] b = s.getBytes();
            fos.write(b);
            System.out.println("Success");
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }
}

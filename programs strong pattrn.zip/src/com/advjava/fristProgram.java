package com.advjava;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class fristProgram {

	public static void main(String[] args) {
		String s="Aniket";
		String path ="D:\\Qspider\\Java advance\\fristProg.txt";
		try {
		 FileOutputStream fos = new FileOutputStream(path);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
	}
}

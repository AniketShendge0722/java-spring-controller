package com.advjava;

public interface predicate<T> {
	abstract boolean test(T a);

}

package com.advjava;
import java.io.*;

public class Deserailization {
    public static void main(String[] args) {
        String path = "D:\\Qspider\\Java advance\\EmployeeInfo.txt";

        File file = new File(path);
        if (!file.exists()) {
            System.out.println("Error: File not found at " + path);
            return;
        }

        try (FileInputStream fis = new FileInputStream(file);
             ObjectInputStream ois = new ObjectInputStream(fis)) {

            Employee e = (Employee) ois.readObject();
            System.out.println("Deserialized Employee: " + e);

        } catch (IOException | ClassNotFoundException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }
}

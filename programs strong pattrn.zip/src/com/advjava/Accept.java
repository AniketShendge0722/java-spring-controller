package com.advjava;

public interface Accept <T>{

	public void accept (T a);

}

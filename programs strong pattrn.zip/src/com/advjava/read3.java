package com.advjava;

public class read3 {

}

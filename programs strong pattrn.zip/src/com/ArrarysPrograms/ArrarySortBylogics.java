package com.ArrarysPrograms;
import java.util.*;
public class ArrarySortBylogics {
	public static void main(String[] args) {
		ArrarySortBylogics s= new ArrarySortBylogics();
		System.out.println(s);
		//accessing the arrays by using  built in method of arrays class that is toString
		int [] arr= {23,43,45,23,46,44,32,3};
		System.out.println("**** Element Before sorting ****");
		System.out.println(Arrays.toString(arr));
			System.out.println();
			System.out.println("****  Element After sorting **** ");
			Arrays.sort(arr);
			System.out.println(Arrays.toString(arr));

}
	}

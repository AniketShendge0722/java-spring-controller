package com.ArrarysPrograms;
import java.util.Scanner;

public class PalindromArray {
	public static void main(String[] args) {
		
		        Scanner s = new Scanner(System.in);

		        System.out.print("Enter the Size of Array: ");
		        int n = s.nextInt();
		        int arr[] = new int[n];

		        System.out.println("Enter " + n + " Elements:");
		        for (int i = 0; i < arr.length; i++) {
		            arr[i] = s.nextInt();  // Corrected input assignment
		        }

		        // Checking if t1he array is a palindrome
		        boolean isPalindrome = true;
		        int start = 0, end = arr.length - 1;

		        while (start < end) {
		            if (arr[start] != arr[end]) {
		                isPalindrome = false;
		                break;
		            }
		            start++;
		            end--;
		        }

		        if (isPalindrome) {
		            System.out.println("The array is a palindrome.");
		        } else {
		            System.out.println("The array is not a palindrome.");
		        }

		        s.close(); // Closing scanner to prevent resource leak
		

	}

}

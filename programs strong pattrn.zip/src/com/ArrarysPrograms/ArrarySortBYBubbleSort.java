package com.ArrarysPrograms;
public class ArrarySortBYBubbleSort {
	public static void main(String[] args) {
		int[] arr= {111,16,13,5,17,23,253};
		System.out.println("**** Element Before sorting ****");
		for(int i = 0 ; i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
		int temp =0;
		 for (int i = 0; i < arr.length - 1; i++) {
	            for (int j = 0; j < arr.length - 1 - i; j++) {
	                if (arr[j] > arr[j + 1]) {
	                    // Swap elements
	                    temp = arr[j];
	                    arr[j] = arr[j + 1];
	                    arr[j + 1] = temp;
	                }
	            }
	        }
	        // Display the sorted array
	        System.out.println("Sorted array:");
	        for (int i = 0; i < arr.length; i++) {
	            System.out.print(arr[i] + " ");
	        }
	}
}

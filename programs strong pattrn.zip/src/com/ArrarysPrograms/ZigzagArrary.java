package com.ArrarysPrograms;

public class ZigzagArrary {
    public static void main(String[] args) {
        int[] arr = {12, 12, 13, 24, 3, 3,5 };
        int[] arr1 = {12, 13, 23, 34, 33,31,4};

        int i = 0, j = 0;
        int len1 = arr.length, len2 = arr1.length;

        System.out.println("Zig-Zag Order:");
        while (i < len1 && j < len2) {
            System.out.print(arr[i++] + " ");  
            System.out.print(arr1[j++] + " ");
        }
        
        while (j < len2) {
            System.out.print(arr1[j++] + " ");
        }
    }
}

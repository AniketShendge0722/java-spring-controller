package com.ArrarysPrograms;
import java.util.Scanner;

public class PrimeNumberOfanArraray {
	public static void main(String[] args) {
		  try (Scanner s = new Scanner(System.in)) {
	        	
				int[] arr= new int [5];
				System.out.print("Enter the  Number :");
				for(int i=0; i<arr.length;i++) {
					arr[i]=s.nextInt();
				}
				
				
				for(int i=0; i<arr.length;i++) {
				
					int count =0;
					for(int j =1;j<=arr[i];j++) {
						if (arr[i]%j==0) {
							count++;
							
						}
					}
					if(count==1) {
						System.out.println( arr[i]+ "  : Prime Number");
					}
					else {
						System.out.println(arr[i] + "  : Not Prime Number");
					}
				}
         }        
		}

}

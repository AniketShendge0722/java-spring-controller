package com.ArrarysPrograms;

public class RemoveVowelFromString {

	public static void main(String[] args) {
		String s = "Aniket Shendge";
		String s1 ="";
		 
		for(int i =0;i<s.length();i++) {
			char ch = s.charAt(i);
		
			 if (ch != 'A' && ch != 'a' && ch !='E' && ch !='e' && ch !='I' && ch!= 'i' &&
                    ch != 'O' && ch !='o' && ch != 'U' && ch != 'u') 
			 {
                  s1 =s1+ch;
                } 
		}
		 System.out.print(s1);
	}
}

package com.ArrarysPrograms;

public class SwapfristHalfToSecoundHalf {
	public static void main(String[] args) {
		int [] arr = {10,20,30,40,50,60,70};
		int mid= 0;
		if(arr.length%2==0) {
			mid =arr.length/2;
		}
		else {
			mid =arr.length/2+1;
			
		}
		int temp =0;
		
		for(int i =0 ; i<arr.length/2;i++) {
			temp =arr[i];
			arr[i]=arr[mid];
			arr[mid++]=temp;
			
			
		}
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]+ "");
		}
		
	}

}

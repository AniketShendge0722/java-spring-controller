package com.ArrarysPrograms;

public class ToPrinttEvenNumberOfWord {

}

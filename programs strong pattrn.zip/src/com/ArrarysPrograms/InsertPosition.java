package com.ArrarysPrograms;
import java.util.Scanner;
public class InsertPosition 
{
	public static void main(String[] args) 
	{
		try (Scanner s = new Scanner (System.in)) 
		{
			System.out.println("enter the size ");
			int size = s.nextInt();
			int[] arr = new  int[size];
			int[] b = new  int[size +1];
			
			System.out.println("Enter the elements ");
			for(int i= 0 ; i<arr.length;i++)
			{
				arr[i]=s.nextInt();
			}
			System.out.println("Enter the Positions : ");
			int pos = s.nextInt();
			System.out.println("Enter the elemet to be   inserted ");
			int ele =s.nextInt();
			if(pos > 0 && pos > arr.length-1)
			{
				System.out.println("Envalid postions ");
			}
			else 
			{
			for(int i= arr.length-1;i>=pos-1;i--)
			{
				b[i+1]=arr[i];
				
			}
			
			b[pos-1]=ele;
			for(int i =0;i<pos-1;i++) {
				b[i]=arr[i];
			}
			System.out.println("================");
			System.out.println("The result is : ");
			for(int i = 0 ; i<b.length;i++) 
			{
				System.out.println(b[i]);
				}
			}
		}
		
	}
}

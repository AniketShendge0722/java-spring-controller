package com.ArrarysPrograms;
import java.util.Scanner;

public class fristProgram {
	public static void main(String[] args) {
		try (Scanner s = new Scanner(System.in)) {
			//	int a = s.nextInt();
				int[] arr= new int [4];
				System.out.println("the array size is  "+ arr.length);
				System.out.println( "enter the elements in array ");
				for(int i=0; i<arr.length;i++) {
					arr[i]=s.nextInt();
					
				}
				System.out.println();
				for(int i=arr.length-1; i>=0; i--){
					System.out.println(arr[i]); 
					
				}
		}
		
		}
		
		
	}


package com.ArrarysPrograms;
public class ConverInitailLetterintoUppercase2 {
	 public static void main(String[] args) {
	        String s = "aniket shendge";
	        String[] s1 = s.split(" "); 
	        String s2=" ";
	        for (int i = 0; i < s1.length; i++) {
	        	char[] ch=s1[i].toCharArray();
	        	for(int j=0 ; j<ch.length;j++) {
	        		
	        	if (j==0&&ch[j]>='a'&&ch[j]<='z') {
	        		s2=s2+(char)(ch[j]-32);
	        		}
	        	else{
	        		s2=s2+ch[j];
	        		
	        	}
	        	}
	        	s2=s2+" ";
	        }
	        	

	        System.out.println(s2);
	    }

}

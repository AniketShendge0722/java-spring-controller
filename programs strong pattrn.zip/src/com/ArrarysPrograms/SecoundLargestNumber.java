package com.ArrarysPrograms;
import java.util.Scanner;
public class SecoundLargestNumber {
	
	    public static void main(String[] args) {
	        Scanner s = new Scanner(System.in);

	        // Taking input for array size
	        System.out.print("Enter the size of the array: ");
	        int n = s.nextInt();

	        // Condition to check if array size is valid
	        if (n < 2) {
	            System.out.println("Array must have at least two elements.");
	            //return;
	        }

	        int arr[] = new int[n];

	        // Taking input for array elements
	        System.out.println("Enter " + n + " elements:");
	        for (int i = 0; i < n; i++) {
	            arr[i] = s.nextInt();
	        }

	        // Finding second largest element
	        int firstLargest = Integer.MIN_VALUE, secondLargest = Integer.MIN_VALUE;

	        for (int num : arr) {
	            if (num > firstLargest) {
	                secondLargest = firstLargest;
	                firstLargest = num;
	            } else if (num > secondLargest && num != firstLargest) {
	                secondLargest = num;
	            }
	        }

	        // Display the result
	        if (secondLargest == Integer.MIN_VALUE) {
	            System.out.println("There is no second largest element.");
	        } else {
	            System.out.println("The second largest element is: " + secondLargest);
	        }

	        s.close(); // Closing scanner
	    

	}

}

package com.ArrarysPrograms;
public class CountTheOnlyCharacters {

	public static void main(String[] args) {
		String s= "Java is progrmming language ";
		char[] ch =s.toCharArray();
		int count= 0;
		for(int i=0; i<s.length();i++) {
			if (ch[i]!=' ') {
				count++;
				
			}
		}
		System.out.println("Number of Charachter Present in String are : "+count);
	}
}

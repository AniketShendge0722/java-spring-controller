package com.ArrarysPrograms;
import java.util.Scanner;

public class SmallestDigtInAnArray {

	public static void main(String[] args) {
		
		
				try (Scanner s = new Scanner(System.in)) {
					System.out.print("Enter the Size of Array: ");
					int n = s.nextInt();
					int arr[] = new int[n];

					System.out.println("Enter " + n + " Elements:");
					for (int i = 0; i < arr.length; i++) {
					    arr[i] = s.nextInt();
					}

					// Initialize smallest with the first element
					int smallest = arr[0];

					// Loop to find the smallest element
					for (int i = 1; i < arr.length; i++) {
					    if (arr[i] < smallest) {
					        smallest = arr[i];
					    }
					}

					System.out.println("The smallest element in the array is: " + smallest);
				}

	
		}

	}


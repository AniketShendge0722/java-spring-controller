package com.ArrarysPrograms;
import java.util.Scanner;

public class SumOfArray {
	public static void main(String[] args) {
		   try (Scanner s = new Scanner(System.in)) {
			System.out.print("Enter the Size of Array: ");
	        int n = s.nextInt();
	        int arr[] = new int[n];

	        System.out.println("Enter " + n + " Elements:");
	        for (int i = 0; i < arr.length; i++) {
	            arr[i] = s.nextInt();
	        }

	        System.out.print("Enter the sum value to find pairs: ");
	        int ele = s.nextInt();

	        System.out.println("Pairs that sum up to " + ele + ":");
	        boolean found = false;

	        for (int i = 0; i < arr.length; i++) {
	            for (int j = i + 1; j < arr.length; j++) {
	                if (arr[i] + arr[j] == ele) {
	                    System.out.println(arr[i] + " + " + arr[j] + " = " + ele);
	                    found = true;
	                }
	            }
	        }

	        if (!found) {
	            System.out.println("No pairs found.");
	        }
		}

		
		
		
	}

}


package com.ArrarysPrograms;
import java.util.Scanner;

public class ReverseArray {
	public static void main(String[] args) {
		try (Scanner s = new Scanner(System.in)) {
			System.out.print("Enter the Size of Array : ");
			int n =s.nextInt();
			int arr[]=new int[n];
			System.out.println("Enter "+n + " Elements :");
			for(int i=0; i<arr.length;i++) {
				arr[i]=s.nextInt();
}

			int start =0;
			int end=arr.length-1;
			while(start>end) {
				int temp = arr[start];
				arr[start]=arr[end];
				arr[end]=temp;
				start++;
				end--;
				
			}
			System.out.println();
			for(int i=arr.length-1; i>=0; i--){
				System.out.println(arr[i]); 
			}
		}
		}

}

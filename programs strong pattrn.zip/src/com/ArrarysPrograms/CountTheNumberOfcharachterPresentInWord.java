package com.ArrarysPrograms;

public class CountTheNumberOfcharachterPresentInWord {

	public static void main(String[] args) {
		String s = "Java is  Programming langauge ";
		int count = 0;
		  for (int i = 0; i < s.length(); i++) {
	            if (s.charAt(i) != ' ') { // If not a space, count characters
	                count++;
	            } else { // When space is found, print the count and reset it
	                System.out.println(  " word length  is "  + " ==> " + count);
	                count = 0;
	            }
	        }
		System.out.println( "  word length  is " + " ==> " +count);
	}
}

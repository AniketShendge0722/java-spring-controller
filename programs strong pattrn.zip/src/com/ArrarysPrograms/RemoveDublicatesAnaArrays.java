package com.ArrarysPrograms;

import java.util.Scanner;

public class RemoveDublicatesAnaArrays {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        // Taking input for array size
        System.out.print("Enter the Size of Array: ");
        int n = s.nextInt();
        int arr[] = new int[n];

        // Taking input for array elements
        System.out.println("Enter " + n + " Elements:");
        for (int i = 0; i < n; i++) {
            arr[i] = s.nextInt();
        }

        // Removing duplicates and printing unique elements
        System.out.println("Array after removing duplicates:");
        for (int i = 0; i < n; i++) {
            boolean isDuplicate = false;

            // Check if the element has appeared before
            for (int j = 0; j < i; j++) {
                if (arr[i] == arr[j]) {
                    isDuplicate = true;
                    break;
                }
            }

            // Print only if it's not a duplicate
            if (!isDuplicate) {
                System.out.print(arr[i] + " ");
            }
        }

        s.close(); // Close the scanner
    }
}

package com.ArrarysPrograms;
import java.util.Scanner;
public class PrintDublicateElements {
 {
	        Scanner s = new Scanner(System.in);


	        System.out.print("Enter the Size of Array: ");
	        int n = s.nextInt();
	        int arr[] = new int[n];

	        // Taking input for array elements
	        System.out.println("Enter " + n + " Elements:");
	        for (int i = 0; i < n; i++) {
	            arr[i] = s.nextInt();
	        }

	        System.out.println("Duplicate elements in the array:");

	        boolean foundDuplicate = false;
	        
	        // Finding and printing only duplicate elements
	        for (int i = 0; i < n; i++) {
	            boolean isDuplicate = false;
	            for (int j = i + 1; j < n; j++) {
	                if (arr[i] == arr[j]) {
	                    isDuplicate = true;
	                    break; // Break after finding a duplicate
	                }
	            }

	            // Printing only if it's a duplicate and hasn't been printed before
	            if (isDuplicate) {
	                // Check if the number was already printed
	                boolean alreadyPrinted = false;
	                for (int k = 0; k < i; k++) {
	                    if (arr[k] == arr[i]) {
	                        alreadyPrinted = true;
	                        break;
	                    }
	                }

	                if (!alreadyPrinted) {
	                    System.out.print(arr[i] + " ");
	                    foundDuplicate = true;
	                }
	            }
	        }

	        if (!foundDuplicate) {
	            System.out.println("No duplicate elements found.");
	        }

	        s.close(); // Close the scanner
 }


}

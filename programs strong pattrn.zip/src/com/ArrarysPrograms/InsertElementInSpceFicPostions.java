package com.ArrarysPrograms;
import java.util.Scanner;

public class InsertElementInSpceFicPostions {
	public static void main(String[] args) {
		try (Scanner s = new Scanner(System.in)) {
			System.out.print("Enter the size of the array: ");
		
			    int size = s.nextInt();

			    int[] arr = new int [size + 1]; // Extra space for new element

			    // Input the elements of the array
			    System.out.println("Enter " + size + " elements:");
			    for (int i = 0; i < size; i++) 
			    {
			        arr[i] = s.nextInt();
			    }

			    // Input the element to insert
			    System.out.print("Enter the element to insert: ");
			    int element = s.nextInt();

			    // Input the position to insert (1-based index)
			    System.out.print("Enter the position to insert (1 to " + (size + 1) + "): ");
			    int position = s.nextInt();

			    // Validate position
			    if (position < 1 || position > size + 1) {
			        System.out.println("Invalid position! Please enter a valid position.");
			    } else {
			        // Shifting elements to the right
			        for (int i = size; i >= position; i--) {
			            arr[i] = arr[i - 1];
			        }

			        // Inserting the new element
			        arr[position - 1] = element;

			        // Display the updated array
			        System.out.println("Updated array:");
			        for (int i = 0; i <= size; i++) {
			            System.out.print(arr[i] + " ");
			        }
			    }
		}
		
	}

}

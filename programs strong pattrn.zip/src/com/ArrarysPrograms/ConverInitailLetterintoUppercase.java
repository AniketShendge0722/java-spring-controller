package com.ArrarysPrograms;

public class ConverInitailLetterintoUppercase {
	String s = "aniket shendge";
	String result = " ";
  int len = s.length();
    if (len > 0) {
        result += Character.toUpperCase(s.charAt(0));
    }
    for (int i = 1; i < len; i++) {
        if (s.charAt(i - 1) == ' ') {
            result += Character.toUpperCase(s.charAt(i)); 
        } else {
            result += s.charAt(i); 
        }
    }
    System.out.println("Converted String: " + result);
}

}

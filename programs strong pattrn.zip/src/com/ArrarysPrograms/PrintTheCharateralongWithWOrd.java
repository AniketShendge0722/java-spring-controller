package com.ArrarysPrograms;
public class PrintTheCharateralongWithWOrd {
 public static void main(String[] args) {
	        String s = "Aniket     Shendge";
	        String[] s1 = s.split(" "); 
	        for (int i = 0; i < s1.length; i++) {
	        	if(s1[i].length()>0) {
	            System.out.println(s1[i] + " -> " + s1[i].length());
	        	}
	        }
	    }
}
	
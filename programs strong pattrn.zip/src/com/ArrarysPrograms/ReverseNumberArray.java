package com.ArrarysPrograms;


public class ReverseNumberArray {
	public static void main(String[] args) {
		int[] a= {12,34,54,87,61};
		System.out.println("Before Reversing each Elements");
		for(int i=0;i<a.length;i++) {
			System.out.println(a[i]);
			
		}
		System.out.println("After Reverse  Each Element ");
		for(int i=0; i<a.length;i++){
			int rev=0;
			while (a[i]!=0) {
				int rem=a[i]%10;
				rev =rev*10+rem;
				a[i]=a[i]/10;
				
				
			}
			System.out.println(rev);
		}
	}

}

package com.ArrarysPrograms;
import java.util.*;
public class SortArrary {
public static void main(String[] args) {
	
	int [] arr= {23,43,45,23,46,44,32,3};
	System.out.println("Element Before sorting ----- ");
	for(int i=0;i<arr.length;i++) {
		System.out.print(" " +arr[i] +" ");	
	}
	System.out.println();
	System.out.println("Element After sorting-------- ");
	Arrays.sort(arr);
	for(int i=0;i<arr.length;i++) {
		System.out.print(" " +arr[i]+" ");
	}
	
}
}

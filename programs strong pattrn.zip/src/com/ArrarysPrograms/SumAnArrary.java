package com.ArrarysPrograms;

public class SumAnArrary {
	public static void main(String[] args) {
		int[] arr= {12,234,34,343,434};
		int res= sum (arr);
		System.out.println("the sum b=of element is "+ res);
		
	}
	public static int sum(int[]b) {
		int sum = 0;
		for(int i=0;i<b.length;i++) {
			sum = sum+b[i];
			
		}
		return sum;
	}

}

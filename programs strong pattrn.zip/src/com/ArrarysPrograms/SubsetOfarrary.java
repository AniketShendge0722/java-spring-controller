package com.ArrarysPrograms;

public class SubsetOfarrary {
	public static void main(String[] args) {
		int[] arr = {1,2,3,4,5,6};
		int[] arr1 = {3,5,6,2,4};
		int count = 0;

		for(int i=0; i <arr1.length;i++) 
		{
			for(int j=0;j<arr.length;j++)
			{
				if(arr1[i]==arr[j]) 
				{
					count++;
					break;
//					System.out.println(" subset is " + arr[i]);
					
				}
				
			}
			
		}
		if(count==arr1.length) {
			System.out.println(" Array arr1 is subset of array A ");
		}
		else {
               System.out.println(" Array arr1 is not sub set of array of A ");
		}
		
	}

}

package com.ArrarysPrograms;

import java.util.Scanner;

public class RemoveDublicateAraray {
	 public static void main(String[] args) {
	        try (Scanner s = new Scanner(System.in)) {
				System.out.print("Enter the Size of Array: ");
				int n = s.nextInt();
				int arr[] = new int[n];

				System.out.println("Enter " + n + " Elements:");
				for (int i = 0; i < n; i++) {
				    arr[i] = s.nextInt();
				}

      
				int unique[] = new int[n];
				int j = 0;

				for (int i = 0; i < n; i++) {
				    boolean isDuplicate = false;

				    // Check if arr[i] is already in the unique array
				    for (int k = 0; k < j; k++) {
				        if (arr[i] == unique[k]) {
				            isDuplicate = true;
				            break;
				        }
				    }                       

				    // If not a duplicate, add it to the unique array
				    if (!isDuplicate) {
				        unique[j++] = arr[i];
				    }
				}

				// Printing the unique elements
				System.out.print("Array after removing duplicates: ");
				for (int i = 0; i < j; i++) {
				    System.out.print(unique[i] + " ");
				}
			}
	 }
}

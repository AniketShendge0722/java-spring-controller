document.addEventListener("DOMContentLoaded", function () {
    function checkAuth() {
        let user = localStorage.getItem("user");
        if (user) {
            document.getElementById("authLinks").style.display = "none";
            document.getElementById("logoutBtn").style.display = "inline";
        }
    }

    window.logout = function () {
        localStorage.removeItem("user");
        window.location.href = "index.html";
    };

    checkAuth();
});
